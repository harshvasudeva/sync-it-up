// ─── SyncTabs Options Page Logic ──────────────────────────────────────────────

const COMPANION_URL = 'https://github.com/user/synctabs-companion/releases';

// DOM elements
const statusDot = document.getElementById('status-dot');
const statusText = document.getElementById('status-text');
const browserIdEl = document.getElementById('browser-id');
const toggleServer = document.getElementById('toggle-server');
const inputServerUrl = document.getElementById('input-server-url');
const toggleAutoDetect = document.getElementById('toggle-auto-detect');
const btnSave = document.getElementById('btn-save');
const btnTest = document.getElementById('btn-test');
const savedMsg = document.getElementById('saved-msg');
const btnGrantPerm = document.getElementById('btn-grant-permission');
const permStatus = document.getElementById('perm-status');
const btnClearRemote = document.getElementById('btn-clear-remote');
const linkCompanion = document.getElementById('link-companion');

// Initialize
async function init() {
  try {
    const state = await chrome.runtime.sendMessage({ type: 'get-state' });
    if (state) {
      // Connection status
      if (state.connected) {
        statusDot.className = 'status-dot online';
        statusText.textContent = `Connected to server — syncing as ${state.browserName}`;
      } else if (state.serverDetected) {
        statusDot.className = 'status-dot offline';
        statusText.textContent = 'Server detected but not connected';
      } else {
        statusDot.className = 'status-dot offline';
        statusText.textContent = 'Running in local-only mode';
      }

      browserIdEl.textContent = state.browserId || '—';

      // Settings
      const settings = state.settings || {};
      toggleServer.checked = settings.serverEnabled !== false;
      inputServerUrl.value = settings.serverUrl || 'ws://127.0.0.1:9234';
      toggleAutoDetect.checked = settings.serverAutoDetect !== false;

      // Permission status
      if (state.hasHostPermission) {
        permStatus.textContent = '✅ Localhost permission granted';
        btnGrantPerm.style.display = 'none';
      } else {
        permStatus.textContent = '⚠️ Localhost permission not granted';
        btnGrantPerm.style.display = 'inline-block';
      }
    }
  } catch (err) {
    statusText.textContent = 'Error communicating with extension';
  }
}

// Save settings
btnSave.addEventListener('click', async () => {
  const newSettings = {
    serverEnabled: toggleServer.checked,
    serverUrl: inputServerUrl.value.trim() || 'ws://127.0.0.1:9234',
    serverAutoDetect: toggleAutoDetect.checked
  };

  try {
    await chrome.runtime.sendMessage({ type: 'update-settings', settings: newSettings });
    savedMsg.classList.add('show');
    setTimeout(() => savedMsg.classList.remove('show'), 2000);
    // Refresh status after save
    setTimeout(init, 1000);
  } catch (err) {
    savedMsg.textContent = 'Error saving';
    savedMsg.classList.add('show');
    setTimeout(() => {
      savedMsg.textContent = 'Saved!';
      savedMsg.classList.remove('show');
    }, 2000);
  }
});

// Test connection
btnTest.addEventListener('click', async () => {
  btnTest.textContent = 'Testing...';
  btnTest.disabled = true;

  try {
    const result = await chrome.runtime.sendMessage({ type: 'reconnect' });
    if (result && result.found) {
      btnTest.textContent = '✓ Server found!';
      btnTest.style.color = 'var(--green)';
    } else {
      btnTest.textContent = '✗ Server not found';
      btnTest.style.color = 'var(--red)';
    }
  } catch {
    btnTest.textContent = '✗ Error';
    btnTest.style.color = 'var(--red)';
  }

  setTimeout(() => {
    btnTest.textContent = 'Test Connection';
    btnTest.style.color = '';
    btnTest.disabled = false;
    init(); // Refresh status
  }, 2500);
});

// Grant permission
btnGrantPerm.addEventListener('click', async () => {
  try {
    const granted = await chrome.permissions.request({
      origins: ['http://127.0.0.1:9234/*']
    });
    if (granted) {
      permStatus.textContent = '✅ Permission granted!';
      btnGrantPerm.style.display = 'none';
      // Tell background to try connecting
      await chrome.runtime.sendMessage({ type: 'reconnect' });
      setTimeout(init, 2000);
    } else {
      permStatus.textContent = '❌ Permission denied';
    }
  } catch (err) {
    permStatus.textContent = '❌ Permission request failed';
  }
});

// Clear remote data
btnClearRemote.addEventListener('click', async () => {
  if (confirm('Clear all cached remote browser tabs? They will re-sync when the server is connected.')) {
    await chrome.runtime.sendMessage({ type: 'clear-remote-browsers' });
    btnClearRemote.textContent = 'Cleared!';
    setTimeout(() => {
      btnClearRemote.textContent = 'Clear Remote Browser Data';
    }, 2000);
  }
});

// Companion link
linkCompanion.addEventListener('click', (e) => {
  e.preventDefault();
  chrome.tabs.create({ url: COMPANION_URL });
});

init();
