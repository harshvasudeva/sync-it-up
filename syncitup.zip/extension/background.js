// ─── SyncTabs Background Service Worker ───────────────────────────────────────
// Works fully standalone (local tab persistence).
// Optionally connects to local SyncTabs Companion server for cross-browser sync.
// Store-compliant: no mandatory external dependencies.

// ─── Default Settings ─────────────────────────────────────────────────────────
const DEFAULTS = {
  serverUrl: 'ws://127.0.0.1:9234',
  serverEnabled: true,       // Try to connect by default
  reconnectMs: 5000,
  syncDebounceMs: 1000,
  serverAutoDetect: true,    // Auto-probe localhost on startup
};

const HEARTBEAT_ALARM = 'synctabs-heartbeat';
const SERVER_DETECT_ALARM = 'synctabs-server-detect';

let ws = null;
let browserId = null;
let browserName = null;
let tabSyncTimeout = null;
let isConnected = false;
let settings = { ...DEFAULTS };
let serverDetected = false;    // Has the local server ever responded?
let reconnectTimer = null;
let firstRun = false;

// ─── Settings ─────────────────────────────────────────────────────────────────
async function loadSettings() {
  const result = await chrome.storage.local.get('synctabs_settings');
  if (result.synctabs_settings) {
    settings = { ...DEFAULTS, ...result.synctabs_settings };
  }
}

async function saveSettings(partial) {
  settings = { ...settings, ...partial };
  await chrome.storage.local.set({ synctabs_settings: settings });
}

// ─── Browser Detection ────────────────────────────────────────────────────────
function detectBrowser() {
  const ua = navigator.userAgent;
  if (ua.includes('Edg/')) return 'Microsoft Edge';
  if (ua.includes('Brave')) return 'Brave';
  if (ua.includes('Vivaldi')) return 'Vivaldi';
  if (ua.includes('OPR/') || ua.includes('Opera')) return 'Opera';
  if (ua.includes('Chrome/')) return 'Google Chrome';
  return 'Chromium Browser';
}

// ─── Unique Browser ID ────────────────────────────────────────────────────────
async function getOrCreateBrowserId() {
  const result = await chrome.storage.local.get(['synctabs_browser_id', 'synctabs_browser_name', 'synctabs_first_run']);
  if (result.synctabs_browser_id) {
    browserId = result.synctabs_browser_id;
    browserName = result.synctabs_browser_name || detectBrowser();
    return;
  }
  // First time install
  firstRun = true;
  const detected = detectBrowser();
  const hex = Array.from(crypto.getRandomValues(new Uint8Array(8)))
    .map(b => b.toString(16).padStart(2, '0')).join('');
  browserId = `${detected.replace(/\s+/g, '-').toLowerCase()}-${hex}`;
  browserName = detected;
  await chrome.storage.local.set({
    synctabs_browser_id: browserId,
    synctabs_browser_name: browserName,
    synctabs_first_run: true
  });
}

// ─── Tab Collection ───────────────────────────────────────────────────────────
async function collectTabs() {
  try {
    const tabs = await chrome.tabs.query({});
    return tabs.map(t => ({
      id: t.id,
      url: t.url || t.pendingUrl || '',
      title: t.title || 'New Tab',
      favIconUrl: t.favIconUrl || '',
      pinned: t.pinned,
      windowId: t.windowId,
      active: t.active,
      lastAccessed: t.lastAccessed || Date.now()
    }));
  } catch (err) {
    console.error('[SyncTabs] Failed to collect tabs:', err);
    return [];
  }
}

// ─── Local Persistence (always works, no server needed) ───────────────────────
async function saveTabsLocally(tabs) {
  await chrome.storage.local.set({
    synctabs_my_tabs: tabs,
    synctabs_my_last_seen: new Date().toISOString()
  });
}

async function saveRemoteBrowsers(browsers) {
  await chrome.storage.local.set({ synctabs_remote_browsers: browsers });
}

async function getRemoteBrowsers() {
  const result = await chrome.storage.local.get('synctabs_remote_browsers');
  return result.synctabs_remote_browsers || {};
}

async function getLocalTabs() {
  const result = await chrome.storage.local.get(['synctabs_my_tabs', 'synctabs_my_last_seen']);
  return {
    tabs: result.synctabs_my_tabs || [],
    lastSeen: result.synctabs_my_last_seen || null
  };
}

// ─── Tab Snapshots (persist tabs on every window close for offline recall) ────
async function saveSnapshot() {
  const tabs = await collectTabs();
  await chrome.storage.local.set({
    synctabs_snapshot: tabs,
    synctabs_snapshot_time: new Date().toISOString()
  });
}

async function getSnapshot() {
  const result = await chrome.storage.local.get(['synctabs_snapshot', 'synctabs_snapshot_time']);
  return {
    tabs: result.synctabs_snapshot || [],
    time: result.synctabs_snapshot_time || null
  };
}

// ─── Server Auto-Detection ────────────────────────────────────────────────────
// Probes the local server with a fetch to the health endpoint.
// Uses optional_host_permissions — will silently fail if not granted.
async function probeServer() {
  if (!settings.serverEnabled) return false;
  try {
    const httpUrl = settings.serverUrl.replace('ws://', 'http://').replace('wss://', 'https://');
    const resp = await fetch(`${httpUrl}/health`, {
      signal: AbortSignal.timeout(2000)
    });
    if (resp.ok) {
      const data = await resp.json();
      if (data.status === 'ok') {
        serverDetected = true;
        return true;
      }
    }
  } catch {
    // Server not running or permission not granted — that's fine
  }
  serverDetected = false;
  return false;
}

// ─── Host Permission ──────────────────────────────────────────────────────────
async function hasHostPermission() {
  try {
    const result = await chrome.permissions.contains({
      origins: ['http://127.0.0.1:9234/*']
    });
    return result;
  } catch {
    return false;
  }
}

async function requestHostPermission() {
  try {
    const granted = await chrome.permissions.request({
      origins: ['http://127.0.0.1:9234/*']
    });
    return granted;
  } catch {
    return false;
  }
}

// ─── WebSocket Connection (only when server detected + enabled) ───────────────
async function connectWebSocket() {
  if (!settings.serverEnabled) return;
  if (ws && (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING)) {
    return;
  }

  // Check if we have permission first
  const hasPerm = await hasHostPermission();
  if (!hasPerm) {
    console.log('[SyncTabs] No host permission for server — skipping connection');
    return;
  }

  try {
    ws = new WebSocket(settings.serverUrl);
  } catch (err) {
    console.warn('[SyncTabs] WebSocket creation failed:', err.message);
    scheduleReconnect();
    return;
  }

  ws.onopen = async () => {
    console.log('[SyncTabs] Connected to server');
    isConnected = true;
    serverDetected = true;

    ws.send(JSON.stringify({
      type: 'register',
      browserId,
      browserName
    }));

    const tabs = await collectTabs();
    await saveTabsLocally(tabs);
    ws.send(JSON.stringify({ type: 'tabs-update', tabs }));

    notifyPopup({ type: 'connection-status', connected: true, serverDetected: true });
  };

  ws.onmessage = async (event) => {
    let msg;
    try { msg = JSON.parse(event.data); } catch { return; }

    switch (msg.type) {
      case 'full-state': {
        const remoteBrowsers = await getRemoteBrowsers();
        const merged = { ...remoteBrowsers, ...msg.browsers };
        await saveRemoteBrowsers(merged);
        notifyPopup({ type: 'state-updated', browsers: merged });
        break;
      }

      case 'browser-tabs-updated': {
        const remoteBrowsers = await getRemoteBrowsers();
        remoteBrowsers[msg.browserId] = {
          browserName: msg.browserName,
          tabs: msg.tabs,
          lastSeen: msg.lastSeen,
          online: msg.online
        };
        await saveRemoteBrowsers(remoteBrowsers);
        notifyPopup({ type: 'state-updated', browsers: remoteBrowsers });
        break;
      }

      case 'presence': {
        const remoteBrowsers = await getRemoteBrowsers();
        if (remoteBrowsers[msg.browserId]) {
          remoteBrowsers[msg.browserId].online = msg.online;
          remoteBrowsers[msg.browserId].lastSeen = msg.lastSeen;
          await saveRemoteBrowsers(remoteBrowsers);
          notifyPopup({ type: 'state-updated', browsers: remoteBrowsers });
        }
        break;
      }
    }
  };

  ws.onclose = () => {
    console.log('[SyncTabs] Disconnected from server');
    isConnected = false;
    ws = null;
    notifyPopup({ type: 'connection-status', connected: false, serverDetected });
    scheduleReconnect();
  };

  ws.onerror = () => {
    console.warn('[SyncTabs] WebSocket error');
  };
}

function scheduleReconnect() {
  if (reconnectTimer) clearTimeout(reconnectTimer);
  reconnectTimer = setTimeout(async () => {
    if (!isConnected && settings.serverEnabled) {
      const found = await probeServer();
      if (found) connectWebSocket();
    }
  }, settings.reconnectMs);
}

// ─── Tab Change Monitoring (always active, even without server) ───────────────
function debouncedTabSync() {
  if (tabSyncTimeout) clearTimeout(tabSyncTimeout);
  tabSyncTimeout = setTimeout(async () => {
    const tabs = await collectTabs();
    await saveTabsLocally(tabs);

    if (ws && ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify({ type: 'tabs-update', tabs }));
    }
  }, settings.syncDebounceMs);
}

// Listen to all tab events
chrome.tabs.onCreated.addListener(debouncedTabSync);
chrome.tabs.onRemoved.addListener(debouncedTabSync);
chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (changeInfo.url || changeInfo.title || changeInfo.status === 'complete') {
    debouncedTabSync();
  }
});
chrome.tabs.onMoved.addListener(debouncedTabSync);
chrome.tabs.onAttached.addListener(debouncedTabSync);
chrome.tabs.onDetached.addListener(debouncedTabSync);
chrome.tabs.onReplaced.addListener(debouncedTabSync);

// Window open/close — also save snapshot on close
chrome.windows.onCreated.addListener(debouncedTabSync);
chrome.windows.onRemoved.addListener(async (windowId) => {
  // Save snapshot immediately — this may be the last window closing
  await saveSnapshot();
  debouncedTabSync();
});

// ─── Communication with Popup / Options ───────────────────────────────────────
function notifyPopup(message) {
  chrome.runtime.sendMessage(message).catch(() => {});
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  switch (msg.type) {
    case 'get-state': {
      (async () => {
        const remoteBrowsers = await getRemoteBrowsers();
        const localTabs = await getLocalTabs();
        const snapshot = await getSnapshot();
        const hasPerm = await hasHostPermission();
        sendResponse({
          connected: isConnected,
          serverDetected,
          serverEnabled: settings.serverEnabled,
          hasHostPermission: hasPerm,
          browserId,
          browserName,
          myTabs: localTabs.tabs,
          myLastSeen: localTabs.lastSeen,
          remoteBrowsers,
          snapshot,
          settings
        });
      })();
      return true;
    }

    case 'force-sync': {
      debouncedTabSync();
      sendResponse({ ok: true });
      return false;
    }

    case 'reconnect': {
      (async () => {
        const found = await probeServer();
        if (found) await connectWebSocket();
        sendResponse({ ok: true, found });
      })();
      return true;
    }

    case 'request-permission': {
      // This must be called from a user gesture context (popup/options page)
      // but we handle it here for state tracking
      (async () => {
        const granted = await hasHostPermission();
        if (granted) {
          const found = await probeServer();
          if (found) await connectWebSocket();
        }
        sendResponse({ granted });
      })();
      return true;
    }

    case 'update-settings': {
      (async () => {
        const oldEnabled = settings.serverEnabled;
        await saveSettings(msg.settings);
        if (settings.serverEnabled && !oldEnabled) {
          const found = await probeServer();
          if (found) connectWebSocket();
        } else if (!settings.serverEnabled && ws) {
          ws.close();
        }
        sendResponse({ ok: true, settings });
      })();
      return true;
    }

    case 'get-settings': {
      sendResponse({ settings });
      return false;
    }

    case 'clear-remote-browsers': {
      (async () => {
        await saveRemoteBrowsers({});
        sendResponse({ ok: true });
      })();
      return true;
    }
  }
});

// ─── Alarms ───────────────────────────────────────────────────────────────────
chrome.alarms.create(HEARTBEAT_ALARM, { periodInMinutes: 1 });
chrome.alarms.create(SERVER_DETECT_ALARM, { periodInMinutes: 5 });

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === HEARTBEAT_ALARM) {
    // Always save tabs locally
    debouncedTabSync();
    // Reconnect if needed
    if (!isConnected && settings.serverEnabled) {
      const found = await probeServer();
      if (found) connectWebSocket();
    }
  }

  if (alarm.name === SERVER_DETECT_ALARM) {
    // Periodic server detection for auto-discovery
    if (settings.serverAutoDetect && !isConnected) {
      const found = await probeServer();
      if (found) {
        notifyPopup({ type: 'server-detected' });
        connectWebSocket();
      }
    }
  }
});

// ─── Install / Update Events ──────────────────────────────────────────────────
chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === 'install') {
    // Open onboarding on first install
    chrome.tabs.create({ url: chrome.runtime.getURL('onboarding.html') });
  }
});

// ─── Startup ──────────────────────────────────────────────────────────────────
(async () => {
  await loadSettings();
  await getOrCreateBrowserId();
  console.log(`[SyncTabs] Browser: ${browserName} (${browserId})`);
  console.log(`[SyncTabs] Server sync: ${settings.serverEnabled ? 'enabled' : 'disabled'}`);

  // Always save tabs locally on startup
  debouncedTabSync();

  // Try to detect and connect to server
  if (settings.serverEnabled) {
    const found = await probeServer();
    if (found) {
      console.log('[SyncTabs] Local server detected — connecting');
      connectWebSocket();
    } else {
      console.log('[SyncTabs] No local server found — running in local-only mode');
    }
  }
})();
