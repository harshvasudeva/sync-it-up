// ─── SyncTabs Popup Logic ─────────────────────────────────────────────────────
// Store-compliant: works fully in local-only mode. Server sync is optional.

const BROWSER_ICONS = {
  'Google Chrome': '🔵',
  'Microsoft Edge': '🟢',
  'Brave': '🟠',
  'Vivaldi': '🔴',
  'Opera': '🔴',
  'Chromium Browser': '⚪'
};

const COMPANION_URL = 'https://github.com/user/synctabs-companion/releases'; // Update with real URL

// ─── DOM Elements ─────────────────────────────────────────────────────────────
const connectionDot = document.getElementById('connection-dot');
const btnSync = document.getElementById('btn-sync');
const btnSettings = document.getElementById('btn-settings');
const selfBrowserIcon = document.getElementById('self-browser-icon');
const selfBrowserName = document.getElementById('self-browser-name');
const selfTabCount = document.getElementById('self-tab-count');
const selfTabsEl = document.getElementById('self-tabs');
const remoteBrowsersEl = document.getElementById('remote-browsers');
const emptyState = document.getElementById('empty-state');
const emptyNoServer = document.getElementById('empty-no-server');
const emptyNoBrowsers = document.getElementById('empty-no-browsers');
const serverStatus = document.getElementById('server-status');
const serverBanner = document.getElementById('server-banner');
const btnEnableSync = document.getElementById('btn-enable-sync');
const btnDismissBanner = document.getElementById('btn-dismiss-banner');
const linkCompanion = document.getElementById('link-companion');

// ─── State ────────────────────────────────────────────────────────────────────
let state = {
  connected: false,
  serverDetected: false,
  serverEnabled: true,
  hasHostPermission: false,
  browserId: null,
  browserName: null,
  myTabs: [],
  remoteBrowsers: {},
  snapshot: { tabs: [], time: null },
  settings: {}
};

// ─── Initialize ───────────────────────────────────────────────────────────────
async function init() {
  try {
    const response = await chrome.runtime.sendMessage({ type: 'get-state' });
    if (response) {
      state = response;
      render();
    }
  } catch (err) {
    console.error('[SyncTabs Popup] Failed to get state:', err);
    serverStatus.textContent = 'Extension error — try reopening';
  }
}

// ─── Render ───────────────────────────────────────────────────────────────────
function render() {
  renderConnectionStatus();
  renderServerBanner();
  renderSelfBrowser();
  renderRemoteBrowsers();
}

function renderConnectionStatus() {
  const hasRemote = Object.keys(state.remoteBrowsers || {}).length > 0;

  if (state.connected) {
    connectionDot.className = 'dot dot-online';
    connectionDot.title = 'Connected to SyncTabs Companion';
    serverStatus.innerHTML = `<span class="mode-badge mode-sync">sync</span> ${state.browserName || 'This Browser'}`;
  } else if (state.serverDetected || hasRemote) {
    connectionDot.className = 'dot dot-stale';
    connectionDot.title = 'Server offline — showing cached data';
    serverStatus.innerHTML = `<span class="mode-badge mode-local">local</span> Server offline · cached data shown`;
  } else {
    connectionDot.className = 'dot dot-offline';
    connectionDot.title = 'Local-only mode';
    serverStatus.innerHTML = `<span class="mode-badge mode-local">local</span> ${state.browserName || 'This Browser'}`;
  }
}

function renderServerBanner() {
  // Show banner if: server not detected, sync enabled, hasn't been dismissed this session
  const hasDismissed = sessionStorage.getItem('synctabs_banner_dismissed');
  const hasRemote = Object.keys(state.remoteBrowsers || {}).length > 0;

  if (!state.connected && !hasRemote && !hasDismissed && state.serverEnabled) {
    serverBanner.style.display = 'block';
  } else {
    serverBanner.style.display = 'none';
  }
}

function renderSelfBrowser() {
  const name = state.browserName || 'This Browser';
  selfBrowserIcon.textContent = BROWSER_ICONS[name] || '🌐';
  selfBrowserName.textContent = `${name} (this)`;
  selfTabCount.textContent = state.myTabs.length;
  selfTabsEl.innerHTML = '';

  if (state.myTabs.length === 0) {
    selfTabsEl.innerHTML = '<div class="empty-state"><p>No tabs found</p></div>';
    return;
  }

  // Group tabs by window
  const windows = {};
  for (const tab of state.myTabs) {
    const wid = tab.windowId || 0;
    if (!windows[wid]) windows[wid] = [];
    windows[wid].push(tab);
  }

  const windowIds = Object.keys(windows);
  for (let i = 0; i < windowIds.length; i++) {
    const wid = windowIds[i];
    const tabs = windows[wid];

    if (windowIds.length > 1) {
      const windowLabel = document.createElement('div');
      windowLabel.className = 'tab-item';
      windowLabel.style.cssText = 'font-size:11px; color:var(--text-dim); padding:4px 14px; cursor:default; border-bottom:1px solid var(--border);';
      windowLabel.textContent = `Window ${i + 1} (${tabs.length} tabs)`;
      selfTabsEl.appendChild(windowLabel);
    }

    for (const tab of tabs) {
      selfTabsEl.appendChild(createTabElement(tab, true));
    }
  }
}

function renderRemoteBrowsers() {
  remoteBrowsersEl.innerHTML = '';
  const browsers = state.remoteBrowsers || {};
  const browserIds = Object.keys(browsers);

  // Empty state logic
  emptyState.style.display = 'none';
  emptyNoServer.style.display = 'none';
  emptyNoBrowsers.style.display = 'none';

  if (browserIds.length === 0) {
    emptyState.style.display = 'block';
    if (!state.connected && !state.serverDetected) {
      emptyNoServer.style.display = 'block';
    } else {
      emptyNoBrowsers.style.display = 'block';
    }
    return;
  }

  // Group by browser name
  const grouped = {};
  for (const [id, data] of Object.entries(browsers)) {
    const name = data.browserName || 'Unknown';
    if (!grouped[name]) grouped[name] = [];
    grouped[name].push({ id, ...data });
  }

  for (const [browserNameGroup, instances] of Object.entries(grouped)) {
    for (const instance of instances) {
      const section = document.createElement('section');
      section.className = 'section';

      const isOnline = instance.online;
      const dotClass = isOnline ? 'dot-online' : 'dot-stale';
      const lastSeenStr = instance.lastSeen ? formatLastSeen(instance.lastSeen) : 'unknown';
      const tabCount = instance.tabs ? instance.tabs.length : 0;
      const icon = BROWSER_ICONS[browserNameGroup] || '🌐';

      section.innerHTML = `
        <div class="section-header">
          <div class="section-title">
            <span class="browser-icon">${icon}</span>
            <span>${browserNameGroup}</span>
            <span class="tab-count">${tabCount}</span>
            <span class="dot ${dotClass}" style="margin-left:6px"></span>
            <span class="last-seen">${isOnline ? 'online' : lastSeenStr}</span>
          </div>
          <svg class="chevron" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M6 9l6 6 6-6"/>
          </svg>
        </div>
        <div class="tab-list"></div>
      `;

      const tabList = section.querySelector('.tab-list');
      if (tabCount === 0) {
        tabList.innerHTML = '<div class="empty-state"><p>No tabs saved</p></div>';
      } else {
        for (const tab of instance.tabs) {
          tabList.appendChild(createTabElement(tab, false));
        }
      }

      const header = section.querySelector('.section-header');
      header.addEventListener('click', () => {
        section.classList.toggle('collapsed');
      });

      remoteBrowsersEl.appendChild(section);
    }
  }
}

// ─── Tab Element ──────────────────────────────────────────────────────────────
function createTabElement(tab, isLocal) {
  const item = document.createElement(isLocal ? 'div' : 'a');
  item.className = 'tab-item';

  if (!isLocal && tab.url && !tab.url.startsWith('chrome://') && !tab.url.startsWith('edge://')) {
    item.href = tab.url;
    item.target = '_blank';
    item.rel = 'noopener';
  }

  if (isLocal) {
    item.addEventListener('click', () => {
      if (tab.id) {
        chrome.tabs.update(tab.id, { active: true });
        if (tab.windowId) {
          chrome.windows.update(tab.windowId, { focused: true });
        }
      }
    });
    item.style.cursor = 'pointer';
  }

  // Favicon
  const faviconUrl = tab.favIconUrl || getFaviconFromUrl(tab.url);
  let favicon;
  if (faviconUrl && !faviconUrl.startsWith('chrome://') && !faviconUrl.startsWith('edge://')) {
    favicon = document.createElement('img');
    favicon.className = 'tab-favicon';
    favicon.src = faviconUrl;
    favicon.onerror = function() {
      this.replaceWith(createFaviconPlaceholder(tab.title));
    };
  } else {
    favicon = createFaviconPlaceholder(tab.title);
  }

  // Info
  const info = document.createElement('div');
  info.className = 'tab-info';

  const title = document.createElement('div');
  title.className = 'tab-title';
  title.textContent = tab.title || 'New Tab';

  const url = document.createElement('div');
  url.className = 'tab-url';
  url.textContent = simplifyUrl(tab.url);

  info.appendChild(title);
  info.appendChild(url);

  item.appendChild(favicon);
  item.appendChild(info);

  if (tab.pinned) {
    const pin = document.createElement('span');
    pin.className = 'tab-pinned-icon';
    pin.textContent = '📌';
    pin.title = 'Pinned';
    item.appendChild(pin);
  }

  if (tab.active && isLocal) {
    const dot = document.createElement('span');
    dot.className = 'tab-active-dot';
    dot.title = 'Active tab';
    item.appendChild(dot);
  }

  return item;
}

function createFaviconPlaceholder(title) {
  const el = document.createElement('div');
  el.className = 'tab-favicon-placeholder';
  el.textContent = (title || '?')[0].toUpperCase();
  return el;
}

// ─── Utilities ────────────────────────────────────────────────────────────────
function getFaviconFromUrl(url) {
  if (!url) return null;
  try {
    const u = new URL(url);
    if (u.protocol === 'chrome:' || u.protocol === 'edge:' || u.protocol === 'about:') return null;
    return `https://www.google.com/s2/favicons?domain=${u.hostname}&sz=32`;
  } catch {
    return null;
  }
}

function simplifyUrl(url) {
  if (!url) return '';
  try {
    const u = new URL(url);
    return u.hostname + (u.pathname !== '/' ? u.pathname : '');
  } catch {
    return url;
  }
}

function formatLastSeen(isoString) {
  const date = new Date(isoString);
  const now = new Date();
  const diff = now - date;
  const seconds = Math.floor(diff / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);

  if (seconds < 60) return 'just now';
  if (minutes < 60) return `${minutes}m ago`;
  if (hours < 24) return `${hours}h ago`;
  if (days < 7) return `${days}d ago`;
  return date.toLocaleDateString();
}

// ─── Event Listeners ──────────────────────────────────────────────────────────

// Toggle self section
document.querySelector('#section-self .section-header').addEventListener('click', () => {
  document.getElementById('section-self').classList.toggle('collapsed');
});

// Settings button
btnSettings.addEventListener('click', () => {
  chrome.runtime.openOptionsPage();
});

// Sync button
btnSync.addEventListener('click', async () => {
  btnSync.style.animation = 'spin 0.5s linear';
  try {
    await chrome.runtime.sendMessage({ type: 'force-sync' });
    setTimeout(async () => {
      const response = await chrome.runtime.sendMessage({ type: 'get-state' });
      if (response) {
        state = response;
        render();
      }
      btnSync.style.animation = '';
    }, 1500);
  } catch {
    btnSync.style.animation = '';
  }
});

// Enable Sync button (requests host permission)
btnEnableSync.addEventListener('click', async () => {
  try {
    // Request permission from popup context (user gesture)
    const granted = await chrome.permissions.request({
      origins: ['http://127.0.0.1:9234/*']
    });
    if (granted) {
      // Tell background to try connecting
      await chrome.runtime.sendMessage({ type: 'reconnect' });
      setTimeout(async () => {
        const response = await chrome.runtime.sendMessage({ type: 'get-state' });
        if (response) {
          state = response;
          render();
        }
      }, 2000);
    }
  } catch (err) {
    console.error('[SyncTabs] Permission request failed:', err);
  }
});

// Dismiss banner
btnDismissBanner.addEventListener('click', () => {
  sessionStorage.setItem('synctabs_banner_dismissed', '1');
  serverBanner.style.display = 'none';
});

// Companion link
linkCompanion.addEventListener('click', (e) => {
  e.preventDefault();
  chrome.tabs.create({ url: COMPANION_URL });
});

// Listen for live updates from background
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === 'state-updated') {
    state.remoteBrowsers = msg.browsers;
    renderRemoteBrowsers();
  }
  if (msg.type === 'connection-status') {
    state.connected = msg.connected;
    state.serverDetected = msg.serverDetected || state.serverDetected;
    renderConnectionStatus();
    renderServerBanner();
  }
  if (msg.type === 'server-detected') {
    state.serverDetected = true;
    renderServerBanner();
  }
});

// ─── Spin animation ──────────────────────────────────────────────────────────
const style = document.createElement('style');
style.textContent = `
  @keyframes spin {
    from { transform: rotate(0deg); }
    to { transform: rotate(360deg); }
  }
`;
document.head.appendChild(style);

// ─── Start ────────────────────────────────────────────────────────────────────
init();
